<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- bootstrap css Link -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap icon cdn file -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Remix icon cdn file -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
    <!-- google fonts link -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300&display=swap" rel="stylesheet">
    <!--  css Link -->
    <link rel="stylesheet" href="css/login.css">
</head>


<body>
    <div class="login-page">
        <div class="form">
            <form class="login-form " action="login.php" method="post" target="_parent">
                <h2>SIGN IN TO YOUR ACCOUNT</h2>
                <input type="text" required placeholder="Email" id="user"  name="email"/>
                <input oninput="return formvalid()" type="password" required placeholder="Password" id="pass" name="pass" autocomplete="off" />
                <img src="https://cdn2.iconfinder.com/data/icons/basic-ui-interface-v-2/32/hide-512.png"
                    onclick="show()" alt="" id="showimg">
                <span id="vaild-pass"></span>
                <button type="submit" name="login">SIGN IN</button>
                <p class="message"><a href="registration.php">Create Account</a></p>
            </form>
        </div>
    </div>
    

<!-- <script src="js/login.js"></script> -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php

include "connection.php";

if(isset($_REQUEST['login']))
{
$uname=$_POST['email'];
$pass=md5($_POST['pass']);

$sql= "SELECT * FROM login WHERE email='$uname' and password='$pass'";


$result=mysqli_query($con,$sql) or die("Query is failed...");


if(mysqli_num_rows($result)>0){
	while($row=mysqli_fetch_assoc($result))
    {
		session_start();
        $_SESSION['username']=$row['email'];
        $_SESSION['pass']=$row['password'];
		echo "<script>
        alert('Successfully login.....');
        window.location.href='index.php';</script>";

		//header("location:index.php");
    }
}
else{
	
	echo "<html><head><script>alert('Username OR Password is Invalid');</script></head></html>";
    //include 'index.php';
}
}
?>
