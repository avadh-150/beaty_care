<?php 

$con=mysqli_connect("localhost","root","","buty") or die("The connection is Fail...");

?>