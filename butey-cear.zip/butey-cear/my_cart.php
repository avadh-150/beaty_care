<?php  
// session_start();  
error_reporting(0);  
include "access.php"; // session

?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>My Cart</title>  

    <link rel="stylesheet" href="css/cart.css">  
    <link rel="stylesheet" href="css/bootstrap.min.css">  
</head>  
<body>  
    <h1>Your Shopping Cart</h1>  

    <?php  
    include "connection.php";  
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {  
        echo "<table>
          
                <tr>  
                    <th>Image</th>  
                    <th>Product Name</th>  
                    <th>Price</th>  
                    <th>Quantity</th>  
                    <th>Total</th>  
                    <th>Action</th>  
                </tr>";  

        // Loop through the cart items and display them  
        $total = 0;  
        foreach ($_SESSION['cart'] as $id => $product) {  
            $subtotal = $product['price'] * $product['quantity'];  
            $total += $subtotal;  
            echo "<tr>  
            <td><img src='img/" . $product['image'] . "' alt='" . $product['title'] . "' width='100'></td>  
            <td>" . htmlspecialchars($product['title']) . "</td>  
            <td>$" . number_format($product['price'], 2) . "</td>  
            <td>" . htmlspecialchars($product['quantity']) . "</td>  
            <td>$" . number_format($subtotal, 2) . "</td>  
            <td><a href='remove_from_cart.php?id=" . htmlspecialchars($id) . "'>Remove</a></td>  
                </tr>";  
        }  

        echo "<tr>  
                <td colspan='4' align='right'><strong>Total:</strong></td>  
                <td>$" . number_format($total, 2) . "</td> 
                     <td> <a href='pay.php'><button class='btn btn-success'>PAYMENT</button></a></td>
 
                <td></td>  
              </tr>";  
        echo "</table>";  
    } else {  
        echo "<p>Your cart is empty.</p>";  
    }  
    ?>  

    <footer>  
        <p>&copy; <?php echo date("d-m-Y"); ?> My Online Store. All rights reserved.</p>  
    </footer>  
</body>  
</html>