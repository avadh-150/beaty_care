
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <!-- bootstrap css Link -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Bootstrap icon cdn file -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <!-- Remix icon cdn file -->
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
  <!-- google fonts link -->
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300&display=swap" rel="stylesheet">
  <!--  css Link -->
  <link rel="stylesheet" href="css/style.css">
  <!-- <link rel="stylesheet" href="css/index.css"> -->
</head>

<body>
  <!-- nav bar start -->
  <?php
  //  error_reporting(0);
  include "nav.php"; ?>
  <!-- nav bar end -->

  <!-- section 1 start -->
  <div class="bg">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="position_relative">
            <img src="img/hero_1_bg_1.webp" class="img-fluid pt-5 " alt="hero_1_bg_1">
            <div class="position_absolult">
              <h1 class="fw-bold display-4">ANTI AGEING</h1>
            </div>
          </div>
          <p class="fs-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sit amet luctus
            venenatis.
          </p>
          <button class="btn1 fw-bold">BUY NOW</button>
        </div>
        <div class="col-md-6">
          <img src="img/hero_1_bg_2.webp" class="img-fluid" alt="hero_1_bg_2">
        </div>
      </div>
    </div>
  </div>
  <!-- section 1 end -->

  <!-- section 2 start -->
  <section class="text-center">
    <div class="container">
      <div class="row">
        <div class="col">
          <h1 class="fw-bold display-4">Best Products</h1>
          <p class="fs-5">Discover our top-rated products and shop for the best deals!</p>
        </div>
      </div>
      <!-- row for product cards -->
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 product-grid">
        <?php
        include "connection.php";
        $sql = "select * from product";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
          <div class="col">
            <div class="card mt-4">
              <img src="img/<?php echo $row['image'] ?>" class="card-img-top img-fluid" alt="<?php echo $row['title'] ?>" name="image">
              <div class="card-body">
                <div class="color_1">
                  <i class="bi bi-star"></i>
                  <i class="bi bi-star"></i>
                  <i class="bi bi-star"></i>
                  <i class="bi bi-star"></i>
                  <i class="bi bi-star-half"></i>
                </div>
                <h4 class="card-title fw-bold pt-2" hidden><?php echo $row['id']?></h4>
                <h4 class="card-title fw-bold pt-2" name="title"><?php echo $row['title'] ?></h4>
                <p class="pt-2 fs-4" name="price">$<?php echo $row['price'] ?><del class="fs-6">$300.00</del></p>
                <a class="btn1 text-capitalize mt-3" href="add_to_cart.php?id=<?php echo $row['id'];?>" style="text-decoration:none;">Add to cart</a>

              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </section>
 <!-- section 2 end -->

  <!-- section 3 start -->
  <section>
    <div class="container">
      <img src="img/bg_3.webp" class="img-fluid" alt="bg_3">
    </div>
  </section>

  <!-- section 5 start -->
  <section class="bg_color">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="section_padding">
            <img src="img/logo.webp" class="img-fluid" alt="logo">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="section_padding">
            <h4 class="fw-bold">Information</h4>
            <ul class="list_tepy">
              <li class="pt-2">
                <a href="blog.html" class="uandarline">Blog</a>
              </li>
              <li class="pt-2">
                <a href="about.html" class="uandarline">About us</a>
              </li>
              <li class="pt-2">
                <a href="contact.html" class="uandarline">Contact</a>
              </li>
              <li class="pt-2">
                <a href="login.html" class="uandarline">Login</a>
              </li>
              <li class="pt-2">
                <a href="shop.html" class="uandarline">Shop</a>
              </li>
            </ul>

          </div>
        </div>
        <div class="col-md-6">
          <div class="section_padding">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d232.4645336424407!2d72.8884521!3d21.21469!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f004ce1b993%3A0x1787eb05d26c7295!2sYogi%20Chok!5e0!3m2!1sen!2sin!4v1725628582530!5m2!1sen!2sin" width="550" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
      <hr>
      <p class="text-center p-3">© 2022 Brancy. Made with by Valamdesign.</p>
    </div>

  </section>
  <!-- section 5 end -->



  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>