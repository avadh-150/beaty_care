
<nav id="app-navbar" class="navbar navbar-inverse navbar-fixed-top primary" style="height:130px;">
  
  <!-- navbar header -->
  <div class="navbar-header" >
   

    <a href="dashboard.php" class="navbar-brand">
    </a>
  </div>
  <!-- .navbar-header -->
  
  <div class="navbar-container container-fluid">
    <div class="collapse navbar-collapse" id="app-navbar-collapse">
      <ul class="nav navbar-toolbar navbar-toolbar-left navbar-left">
        
        <li>
          <h5 class="page-title hidden-menubar-top hidden-float" style="font-size:28px; margin-top:10px; ">Dashboard</h5>
        </li>
      </ul>

      
    </div>
  </div><!-- navbar-container -->
</nav>