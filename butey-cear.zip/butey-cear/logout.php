<?php 
//  $conn=mysqli_connect("localhost","root","","gymsite") or die("connection is failed....");
include "includes/dbconnection.php";
    session_start();

    session_unset();
    session_destroy();

header("location:login.php")

?>