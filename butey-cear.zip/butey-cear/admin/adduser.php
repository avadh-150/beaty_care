<?php
session_start();
error_reporting(0);
include('connection.php');
if (!isset($_SESSION['email'])) {
  header('location:logout.php');
  } else{

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content=
        "width=device-width, initial-scale=1.0" />
    <title>Form Validation</title>
    <link rel="stylesheet" href="assets/css/registration.css" />
</head>

<body>
    <h1>Add Users</h1>
    <form method="post" action="adduser.php" name="RegForm" onsubmit="return validateForm()">
        <p>
            <label for="name">Name:</label>
            <input type="text" id="name" name="Name" 
                placeholder="Enter your full name" />
            <span id="name-error" class="error-message"></span>
        </p>
        <!-- <p>
            <label for="address">Address:</label>
            <input type="text" id="address" name="Address" 
            placeholder="Enter your address" />
        </p> -->
        <p>
            <label for="email">E-mail Address:</label>
            <input type="text" id="email" name="EMail" 
            placeholder="Enter your email" />
            <span id="email-error" class="error-message"></span>
        </p>
        <p>
            <label for="email">Contact No.</label>
            <input type="text" id="contact" name="contact" 
            placeholder="Enter your contact number" />
            <span id="contact-error" class="error-message"></span>
        </p>
        <p>
            <label for="password">Password:</label>
            <input type="password" id="password" name="Password" />
            <span id="password-error" class="error-message"></span>
        </p>
        <p>
            <label for="comment">Address:</label>
            <textarea  id="address" name="Address" 
            placeholder="Enter your address"></textarea>
            <span id="address-error" class="error-message"></span>
        </p>
        <p>
            <label for="subject">Select Your Gender:</label>
            <select id="subject" name="Subject">
               
                <option value="Male">
                    Male
                </option>
                <option value="Female">
                    Female
                </option>
            </select>
            <span id="subject-error" class="error-message"></span>
        </p>
        <p>
            <label for="comment">College Name:</label>
            <textarea id="comment" name="Comment"></textarea>
        </p>
        <p>
            <input type="checkbox" id="agree" name="Agree" />
            <label for="agree">I agree to the above
                information</label>
            <span id="agree-error" class="error-message"></span>
        </p>
        <p>
            <input type="submit" value="Send" name="Submit" />
            <input type="reset" value="Reset" name="Reset" />
        </p>
    </form>
    <script src="../js/registration.js"></script>
</body>

</html>

<?php
include "connection.php";
if (isset($_REQUEST['Submit'])) {
    
    $uname = $_POST['Name'];
    $email = $_POST['EMail'];
    $pass = md5($_POST['Password']);
    $no = $_POST['contact'];
    $ad = $_POST['Address'];
    $college = $_POST['Comment'];
    $gn = $_POST['Subject'];
   

    $sql = "insert into register(uname,email,password,address,gender,college,contact) values('$uname','$email','$pass','$ad','$gn','$college','$no')";
    $sql1="insert into login values('$email','$pass')";
    $result = mysqli_query($con, $sql) or die("some query issues....");
    $result1 = mysqli_query($con, $sql1) or die("some query issues....");
    
    if ($result && $result1) {
        echo "<script>alter('register the record..........')</script>";

       // header("location:login.php");
                     echo "<script>window.location.href='user.php';</script>";
    } else {
        echo "error......";
    }
}}
?>
