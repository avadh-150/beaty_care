<?php   

include "access.php";
echo "<script>

alert('Payment has been shipped to delivery....!');
window.location.href='index.php';
</script>";
// header('Location: my_cart.php');


?>