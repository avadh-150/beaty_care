
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- bootstrap css Link -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap icon cdn file -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Remix icon cdn file -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
    <!-- google fonts link -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300&display=swap" rel="stylesheet">
    <!--  css Link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- nav bar start -->
    <?php include "nav.php"; ?>

    <!-- nav bar end -->

    <!-- section 1 start -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1 class="fw-bold mt-5 display-4">Get in touch</h1>
                <p class="fs-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam purus sit amet luctus
                    venenatis</p>
                <form class="row g-3 mt-5 needs-validation" novalidate>
                    <div class="col-md-6">
                        <label for="validationCustom01" class="form-label">First name</label>
                        <input type="text" class="form-control" id="validationCustom01" required>
                        <div class="invalid-feedback">
                            Please enter a last name.
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="validationCustom02" class="form-label">Last name</label>
                        <input type="text" class="form-control" id="validationCustom02" required>
                        <div class="invalid-feedback">
                            Please enter a last name.
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="validationCustomUsername" class="form-label">Username</label>
                        <div class="input-group has-validation">
                            <span class="input-group-text" id="inputGroupPrepend">@</span>
                            <input type="text" class="form-control" id="validationCustomUsername"
                                aria-describedby="inputGroupPrepend" required>
                            <div class="invalid-feedback">
                                Please choose a username.
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="validationCustom03" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="validationCustom03" required>
                        <div class="invalid-feedback">
                            Please provide a valid city.
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                            <label class="form-check-label" for="invalidCheck">
                                Agree to terms and conditions
                            </label>
                            <div class="invalid-feedback">
                                You must agree before submitting.
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit">Submit form</button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <img src="img/about_bg_2.webp" class="img-fluid" alt="">
            </div>
        </div>
    </div>
    <!-- section 1 end -->

    <!-- section 5 start -->
    <div class="bg_color">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="section_padding">
                        <img src="img/logo.webp" class="img-fluid" alt="logo">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="section_padding">
                        <h4 class="fw-bold">Information</h4>
                        <ul class="list_tepy">
                            <li class="pt-2">
                                <a href="#" class="uandarline">Blog</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">About us</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Contact</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Login</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Shop</a>
                            </li>
                        </ul>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section_padding">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d232.4645336424407!2d72.8884521!3d21.21469!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f004ce1b993%3A0x1787eb05d26c7295!2sYogi%20Chok!5e0!3m2!1sen!2sin!4v1725628582530!5m2!1sen!2sin"
                            width="550" height="250" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
            <hr>
            <p class="text-center p-3">© 2022 Brancy. Made with by Valamdesign.</p>
        </div>

    </div>
    <!-- section 5 end -->


    <script src="js/app.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>