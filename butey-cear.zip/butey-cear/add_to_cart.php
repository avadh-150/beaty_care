<!-- <?php 
session_start();
if(!isset($_SESSION['username'])) {   
    header('location:logout.php');
    exit;
} else {
    include "connection.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="css/cad.css">
</head>
<body>

<div class="container">
    <h2>Your Shopping Cart</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>Price Per Unit</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
        <?php         include "connection.php";
        $name=$_GET['id'];
                            $sql = "select * from product where id='$name';";
                            $result = mysqli_query($con, $sql) or die("some query issues....");
                            while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                                <td name="remove_code[]"><?php echo $row['id'] ?></td>
                                <td><?php echo $row['title'] ?></td
                                <td>$<?php echo $row['price'] ?></td>
                                <td>
                                    <img src="img/<?php echo $row['image']?>" alt="">
                                </td>
                                
                                </tr>
                            <?php } ?>
        </tbody>
    </table>

    <div class="cart-buttons">
        <a href="index.php"><button type="button">Continue Shopping</button></a>
        <button type="button">Update Shopping Cart</button>
    </div>
</div>

</body>
</html>

<?php } ?>

 -->

 <?php
session_start();
include "connection.php"; // Connection to the database
include "access.php"; // session

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch the product details from the database
    $sql = "SELECT * FROM product WHERE id = '$product_id'";
    $result = mysqli_query($con, $sql);
    $product = mysqli_fetch_assoc($result);

    if ($product) {
        // Create the session cart if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }

        // Check if the product is already in the cart
        if (isset($_SESSION['cart'][$product_id])) {
            // Increment the quantity if the product is already in the cart
            $_SESSION['cart'][$product_id]['quantity'] += 1;
        } else {
            // Add the product to the cart with an initial quantity of 1
            $_SESSION['cart'][$product_id] = array(
                'title' => $product['title'],
                'price' => $product['price'],
                'image' => $product['image'],
                'quantity' => 1
            );
        }
    }

    // Redirect to the cart page or back to the product list
    header('Location: my_cart.php');
    exit();
}
?>
