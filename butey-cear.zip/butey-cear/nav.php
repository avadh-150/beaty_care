
<nav class="navbar navbar-expand-lg nav-underline">
    <div class="container-fluid">

      <a class="navbar-brand" href="#"><img src="img/logo.webp" class="img-fluid w-75" alt="logo">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="about.php">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="shop.php">Shop</a>
          </li>
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="blog.php">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="admin/login.php">Admin</a>
          </li>
        </ul>
        <div class="d-flex">
        <?php
                 session_start();
                if (!isset($_SESSION["username"])) {
                ?>
            <a href="login.php" class="text-black" style="text-decoration: none;"><i class="bi bi-person-fill me-4 fs-5" >Login</i></a>
            <a href="my_cart.php" class="text-black"><i class="bi bi-basket me-4 fs-5"></i></a>
            <!-- <a href="#" class="text-black"><i class="bi bi-search me-4 fs-5"></i></a> -->
            <?php }
               else if(isset($_SESSION["username"])) {
                ?>

            <a href="#" class="text-black"  style="text-decoration: none; margin-top:10px; font-size:17px; font-weight:bold;"><?php echo $_SESSION['username']." "; ?><i class="bi bi-person-fill me-4 fs-5"></i></a>
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link me-3 fs-5" href="logout.php">logout</a>
          </li>
          </ul>
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
          <a href="my_cart.php" class="text-black"><i class="bi bi-basket me-4 fs-5"></i></a>
          </li>
          </ul>
          <?php }?>
        </div>
      </div>
    </div>
    </div>
  </nav>
