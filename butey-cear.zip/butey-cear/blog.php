
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- bootstrap css Link -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap icon cdn file -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Remix icon cdn file -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
    <!-- google fonts link -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300&display=swap" rel="stylesheet">
    <!--  css Link -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- nav bar start -->
    <?php include "nav.php"; ?>

    <!-- nav bar end -->

    <!-- section 1 start -->
    <div class="blog_bg rounded-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="">
                        <img src="img/blog_bg_2.webp" class="img-fluid pt-5 " alt="hero_1_bg_1">
                        <div class="">
                            <h1 class="fw-bold display-4">Whats the beauty <br> secrets?</h1>
                        </div>
                    </div>
                    <p class="fs-5 fw-bold text-muted"> Lorem ipsum dolor sit amet, consectetur adipiscing elit ut <br>
                        aliquam, purus sit
                        amet luctus
                        venenatis.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- section 1 end -->

    <!-- section 2 start -->
    <section class="text-center">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class="fw-bold display-4">Others Posts</h1>
                    <p class="fs-5 fw-bold text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit <br> ut
                        aliquam, purus sit
                        amet luctus
                        venenatis</p>
                </div>
            </div>
            <!-- row 1 strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-9.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-10.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-11.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row 1 end -->
        </div>
    </section>
    <!-- section 2 end -->

    <!-- section 3 start -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="text-center ">
                        <img src="img/blog_bg_3.webp" class="img-fluid rounded-5" alt="blog_bg_3">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section 3 end -->

    <!-- section 4 start -->
    <section>
        <div class="container">
            <!-- row 2 strat -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-12.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-13.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mt-5 border-0">
                        <img src="img/card-14.webp" class="card-img-top img-fluid" alt="card-1">
                        <div class="card-body text-start">
                            <button class="btn2 fw-bold" type="button">
                                beauty
                            </button>
                            <h4 class="card-title fw-bold pt-2 text_hover">Lorem ipsum dolor sit amet consectetur
                                adipiscing.</h4>
                            <p class="text_hover"> <span class="me-5">By: Tomas De Momen</span>
                                <span>February 13, 2022</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row 2 end -->
        </div>
    </section>
    <!-- section 4 end -->

    <!-- section 5 start -->
    <section class="bg_color">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="section_padding">
                        <img src="img/logo.webp" class="img-fluid" alt="logo">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="section_padding">
                        <h4 class="fw-bold">Information</h4>
                        <ul class="list_tepy">
                            <li class="pt-2">
                                <a href="#" class="uandarline">Blog</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">About us</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Contact</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Login</a>
                            </li>
                            <li class="pt-2">
                                <a href="#" class="uandarline">Shop</a>
                            </li>
                        </ul>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section_padding">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d232.4645336424407!2d72.8884521!3d21.21469!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f004ce1b993%3A0x1787eb05d26c7295!2sYogi%20Chok!5e0!3m2!1sen!2sin!4v1725628582530!5m2!1sen!2sin"
                            width="550" height="250" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
            <hr>
            <p class="text-center p-3">© 2022 Brancy. Made with by Valamdesign.</p>
        </div>

    </section>
    <!-- section 5 end -->



    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>