
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <!-- bootstrap css Link -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Bootstrap icon cdn file -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <!-- Remix icon cdn file -->
  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
  <!-- google fonts link -->
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300&display=swap" rel="stylesheet">
  <!--  css Link -->
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <!-- nav bar start -->
  <?php include "nav.php"; ?>

  <!-- nav bar end -->

  <!-- section 1 start -->
  <div class="bg_about">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="position_relative_1">
            <img src="img/about_bg_1.webp" class="img-fluid pt-5" alt="about_bg_1">
            <div class="position_absolult_1">
              <h1 class="fw-bold display-4">We, are Brancy</h1>
            </div>
          </div>
          <p class="fs-4 text-decoration-underline">Best cosmetics provider</p>
          <p class="fs-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam, purus sit amet
            luctus
            venenatis.
          </p>

        </div>
        <div class="col-md-6">
          <img src="img/about_bg_2.webp" class="img-fluid" alt="about_bg_2">
        </div>
      </div>
    </div>
  </div>
  <!-- section 1 end -->

  <!-- section-2 start -->
  <section class="src-1 mt-5 " id="service">
    <div class="container ">
      <div class="row">
        <div class="col">
          <h1 class="text-center"><strong>OUR SERVICES</strong></h1><br>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title hover_0 fs-3 text-center color_1"><strong>
                  Clients</strong></h5>
              <div class="text-center">
                <img src="img/funfact1.webp" class="bg-img rounded-5 mt-3" alt="img-1">
              </div>
              <h1 class="card-text text-black mt-3 text-center ">
                5000+
              </h1>

            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title hover_0 fs-3 text-center color_1"><strong>
                  Projects</strong></h5>
              <div class="text-center">
                <img src="img/funfact2.webp" class="bg-img rounded-5 mt-3" alt="img-2">
              </div>
              <h1 class="card-text text-black  mt-3 text-center">
                250+
              </h1>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title  fs-3 text-center color_1"><strong>Revenue
                </strong></h5>
              <div class="text-center">
                <img src="img/funfact3.webp" class="bg-img rounded-5 mt-3" alt="img-3">
              </div>
              <h1 class="card-text text-black mt-3 text-center">
                1.5M+
              </h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- section-2 end -->

  <!-- section-3 start -->
  <section>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="text-center">
            <img src="img/about2.webp" alt="about2" class="img-fluid">
          </div>
          <h1 class="text-center mt-5 display-3">Best Cosmetics Provider</h1>
          <p class="text-center fs-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In vel arcu
            aliquet sem risus nisl. Neque, scelerisque in erat lacus ridiculus habitant porttitor. Malesuada
            pulvinar sollicitudin enim, quis sapien tellus est. Pellentesque amet vel maecenas nisi. In
            elementum magna nulla ridiculus sapien mollis volutpat sit. Arcu egestas massa consectetur felis
            urna porttitor ac.</p>
        </div>
      </div>
    </div>
  </section>
  <!-- section-3 end-->

  <!-- section-4 start-->
  <section class="src-1 mt-5" id="service">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title hover_0 fs-3 text-black"><strong>Support Team
                </strong></h5>
              <div>
                <img src="img/feature1.webp" class="bg-img rounded-5 mt-3" alt="img-1">
              </div>
              <p class="card-text hover_0 mt-3 text-black">
                Lorem ipsum dolor amet, consectetur adipiscing. Ac tortor enim metus, turpis. Effective strategies to
                help
                you reach
                customers.
              </p>

            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title hover_0 fs-3 text-black"><strong>Certification</strong></h5>
              <div>
                <img src="img/feature2.webp" class="bg-img rounded-5 mt-3" alt="img-2">
              </div>
              <p class="card-text hover_0 mt-3 text-black">
                adipiscing. Ac tortor enim metus, turpis.

                IconCertification
                Lorem ipsum dolor amet, consectetur adipiscing. Ac tortor enim metus, turpis
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="card card_0 mx-auto border-0 mt-3 p-4">
            <div class="card-body">
              <h5 class="card-title hover_0 fs-3 text-black"><strong>Natural Products</strong></h5>
              <div>
                <img src="img/feature3.webp" class="bg-img rounded-5 mt-3" alt="img-3">
              </div>
              <p class="card-text hover_0 mt-3 text-black">
                adipiscing. Ac tortor enim metus, turpis. IconCertification Lorem ipsum dolor amet, consectetur adipiscing. Ac tortor enim metus, turpis
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- section-4 end-->

  <!-- section 5 start -->
  <section class="bg_color">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="section_padding">
            <img src="img/logo.webp" class="img-fluid" alt="logo">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
          </div>
        </div>
        <div class="col-md-3">
          <div class="section_padding">
            <h4 class="fw-bold">Information</h4>
            <ul class="list_tepy">
              <li class="pt-2">
                <a href="#" class="uandarline">Blog</a>
              </li>
              <li class="pt-2">
                <a href="#" class="uandarline">About us</a>
              </li>
              <li class="pt-2">
                <a href="#" class="uandarline">Contact</a>
              </li>
              <li class="pt-2">
                <a href="#" class="uandarline">Login</a>
              </li>
              <li class="pt-2">
                <a href="#" class="uandarline">Shop</a>
              </li>
            </ul>

          </div>
        </div>
        <div class="col-md-6">
          <div class="section_padding">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d232.4645336424407!2d72.8884521!3d21.21469!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f004ce1b993%3A0x1787eb05d26c7295!2sYogi%20Chok!5e0!3m2!1sen!2sin!4v1725628582530!5m2!1sen!2sin"
              width="550" height="250" style="border:0;" allowfullscreen="" loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
      <hr>
      <p class="text-center p-3">© 2022 Brancy. Made with by Valamdesign.</p>
    </div>

  </section>
  <!-- section 5 end -->


  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>